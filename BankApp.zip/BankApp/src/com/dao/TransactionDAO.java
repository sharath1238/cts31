package com.dao;

import java.util.ArrayList;
import java.util.List;

import com.model.Transaction;

public class TransactionDAO {
	
	List<Transaction> transactionList = new  ArrayList<Transaction>();

	public List<Transaction> GetTransactionList() {
		return transactionList;
	}

    public void addTransaction(Transaction obj){
    	transactionList.add(obj);
    }
	
    public void removeObj(int TransactionId){
    	
    }
}
