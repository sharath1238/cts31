package com.dao;


import java.util.ArrayList;
import java.util.List;

import com.model.Customer;
import com.model.Account;

import java.io.IOException;

public class AccountDAO {
	
	List<Account> AccountList = new ArrayList<>();
	
	public void addAccount(Account account){
		AccountList.add(account);
	}
	
	public Account viewAccountByAccountNumber(int accountNumber) {
		
		if(AccountList.size()==0)
			return null;
		else
			for(Account a : AccountList)
				if(a.getAccountNumber()==accountNumber)
					return a;
		return null;	
	}

}
