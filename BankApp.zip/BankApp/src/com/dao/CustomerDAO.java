package com.dao;

import java.util.*;

import com.model.Customer;

public class CustomerDAO {
	
	List<Customer> customerList = new ArrayList<>();
	
	public void AddCustomer(Customer customer){
		customerList.add(customer);
	}
	
	public List<Customer> viewAllCustomer(){
		if(customerList.size()==0){
			return null;
		}
		return customerList;		
	}
	
	public boolean updatePan(int customerId,String panNumber){
		boolean flag=false;
		for(Customer c : customerList){
			if(c.getCustomerId()==customerId){
				c.setPanNumber(panNumber);
				return true;
			}
		}
		return false;
	}

}
