package com.model;

public class Account {
	int accountNumber;
	String account_Type="Savings";
	Customer customer;
	double balance;
	static final float minimumBalance=5000;
	static final float transactionCharges=150;
	
	public Account(){
		
	}	
	
	public Account(int accountNum, String account_Type, Customer customer, double balance) {		
		this.accountNumber = accountNumber;
		this.account_Type = account_Type;
		this.customer = customer;
		this.balance = balance;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getAccount_Type() {
		return account_Type;
	}

	public void setAccount_Type(String account_Type) {
		this.account_Type = account_Type;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public static float getMinimumbalance() {
		return minimumBalance;
	}

	public static float getTransactioncharges() {
		return transactionCharges;
	}

	public void deposit(double amount){
		balance=balance + amount;
	}
	
	public void withdraw(double amount){
		balance=balance - amount;
	}	
	
	public boolean CheckBalance(double amount){
		double bal=0;
		if(balance-amount > minimumBalance)
			return true;
		else
			return false;
	}
}
